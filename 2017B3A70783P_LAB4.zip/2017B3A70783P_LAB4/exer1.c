#include <stdio.h>
#include<stdlib.h>

void p(int m)
{
   unsigned int pilani;
   printf("%u",&pilani);
    if(m>=0)
    p(m+1);
}

void g()
{
  unsigned int goa;
   printf("%u",&goa);
}

void h()
{
   unsigned int hyder;
    printf("%u",&hyder);
}

void d()
{
    unsigned int dubai;
printf("%u",&dubai);
}

int main()
{
    g();
    h();
    d();
    p(0);
    return 0;
}

