#include "linkedlist.h"
#include <stdlib.h>
int totAllocSpace=0;
void* myalloc(int size){totAllocSpace+=size;return malloc(size);}
void myfree(void* ptr, int size){totAllocSpace-=size; free(ptr);}

void insertFirst(Ls head, int ele){
	Node *link = (Node*) myalloc (sizeof(Node)); 
	link->element = ele;
	if(head->count!=0) link->next = head->first;
	else link->next=NULL;
	head -> first = link;
	head -> count ++;
}

Node* deleteFirst(Ls head){
	Node *ptr = head->first;
	if( head-> count == 0)
		return NULL;

	head->first = (head->first)->next;
	head->count --;
	myfree(ptr,sizeof(Node));
	return ptr;
}

void printCList(Ls head, int size){
	Node *ptr = head->first;
	printf("\n[ ");
	while(size--){
		printf("%d, ", ptr->element);
		ptr = ptr->next;
	}
	printf(" ]");
}

void printList(Ls head){
	printCList(head, head->count);
}

int getHeapMemory(){return totAllocSpace;}
