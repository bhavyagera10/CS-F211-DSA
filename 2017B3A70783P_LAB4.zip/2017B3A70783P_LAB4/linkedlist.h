#include <stdio.h>
#include <stdlib.h> 
#include<stdbool.h>

typedef struct node {
int element;
struct node * next;
} Node;

typedef struct ll {
int count;
Node* first;
} LinkedList;

typedef LinkedList *Ls;

void insertFirst (Ls head, int ele);
Node* deleteFirst(Ls head);
void printList (Ls head);
void printCList(Ls head, int size);
int search (Ls head, int ele);
Node* delete (Ls head, int ele);

void* myalloc(int size);
void myfree(void* ptr, int size);
int getHeapMemory();

bool testCycle(LinkedList * ls);

LinkedList * makeCircularList(LinkedList* ls);

