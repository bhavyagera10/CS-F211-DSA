#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include <sys/time.h>
#include"linkedlist.h"

LinkedList * createList(int n)
{
    // srand(time(0));
     LinkedList* list=(LinkedList * )malloc(sizeof(LinkedList));
     while(n--)
     {
         int g=rand()%10;
         insertFirst(list,g);

     }
     return list;
}

 LinkedList * createCycle(int n){
	LinkedList * my= createList(n);
	//srand(time(0));
	if(rand()%2) return my;
	Node * last = my->first;
	Node * run = my->first;
	while(last->next){ last = last->next; }
	int s = rand()%(n-1) + 1 ;
	while(s--){ run = run->next; }
	last->next = run;
	return my;
}


int main(int num, char *val[]){
	if(num!=2) {
		printf("ERROR  Please give appropriate inputs\n");
		return 0;
	}
	int n=atoi(val[1]);
	struct timeval t1, t2;
	double elapsedTime;
	gettimeofday(&t1, NULL);
	LinkedList* gg = createCycle(n);
	 
	 
	gettimeofday(&t2, NULL);
	elapsedTime = (t2.tv_sec - t1.tv_sec) * 1000.0;
	elapsedTime += (t2.tv_usec - t1.tv_usec) / 1000.0;
	//printf("Total time is %lf ms.\n",elapsedTime);
	//printf("Memoty used : %d\n",getHeapMemory());
	printf("%lf %d\n",elapsedTime,getHeapMemory());
	return 1;
}