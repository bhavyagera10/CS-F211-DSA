#include "linkedlist.h"

 bool testCycle(LinkedList * my){
	if(my->count<3)
		return false;
	Node * tort = my->first;
	Node * hare = (my->first)->next;
	while(hare!=NULL){
		if( tort != hare ){
			tort = tort -> next;
			if(!hare->next)
				return false;
			hare = hare -> next->next;
		}
		else
			return true;
	}
	return false;
}
