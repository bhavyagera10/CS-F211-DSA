#include<stdio.h>
#include<stdlib.h>
//#include "linkedlist.h"
int allspace=0;
void * myalloc(int n)
{
     allspace+=n;
     void* ptr=malloc(n*sizeof(int));
     return ptr;
}

void myfree(void * p,int size)
{
     allspace-=size;
     free(p);
}

void myloop()
{
    int m= ((rand()%10) * 10000);
   // Node * p=(Node *)malloc(m*sizeof(Node));
  void * p= myalloc(m);
  printf("%u\n",p);
  printf("%u\n",&p[m-1]);


}
 int main()
 {
     myloop();
     return 0;
 }