#include "linkedlist.h"
// #include <stdbool.h>

bool testCycle(LinkedList * my){ 
    Node* pre = NULL; 
    Node* cur = my->first; 
    Node* nex = NULL;
     
    while (cur != NULL) {
        nex = cur->next; 
        cur->next = pre; 
        pre = cur; 
        cur = nex; 
    } 
    if(pre==my->first) return true;
    my->first=pre;
    return false;
} 
