#include "Stack.h"


void push(struct linkedList *head, int ele)
{  insertfirst(head,ele);
}

struct node * pop(struct linkedList *head)
{
  deletefirst(head);
}

void printstack(struct linkedList *head)
{
  printlist(head);
}

