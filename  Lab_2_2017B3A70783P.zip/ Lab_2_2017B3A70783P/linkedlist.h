//linkedlist.h
#include<stdio.h>

struct node{
  int ele;
  struct node *next;
};

struct linkedList{
  int count;
  struct node *first;
};
//function definitions
void insertfirst(struct linkedList *head, int ele);
struct node * deletefirst(struct linkedList *head);
void printlist(struct linkedList *head);
int search(struct linkedList *head, int ele);
struct node * delete(struct linkedList *head, int ele);
