#include "linkedlist.h"
#include<stdlib.h>

void insertfirst(struct linkedList *head, int ele)
{  struct node *link = (struct node*) malloc(sizeof(struct node));
   link->ele = ele;
   link->next = head->first;
  
   head->first = link;
   head->count ++;
}

struct node * deletefirst(struct linkedList *head){

struct node * cc= head->first;
head->first = cc->next;
head->count--;

return cc;

}

void printlist(struct linkedList *head)
{
  struct node *ptr = head->first ;
  printf("\n[");

while( ptr != NULL)
{
  printf("%d -> ",ptr->ele);
  ptr = ptr-> next;
}
printf(" ]");

}

int search(struct linkedList *head,int ele)
{
  struct node *ptr = head->first;
  while(ptr!= NULL){
   if (ptr->ele == ele) 
   {return 1; }
   ptr= ptr-> next;
  }
  
  return 0;
}

struct node * delete(struct linkedList *head, int ele){

  struct node *bef = NULL;
  
  struct node *temp = NULL;

  struct node *ptr = head->first;
while( ptr!=NULL)
{
  if( ptr->ele == ele)
  { if(bef){ 
    temp = ptr;
    bef->next = ptr->next;
    }
    else
    {
      temp = ptr;
      head->first = ptr->next;
    }
  }

bef = ptr;
ptr = ptr->next;

}   
  
if(temp) 
{return(temp);}
else 
{printf("Element Not Found");}

}


  

