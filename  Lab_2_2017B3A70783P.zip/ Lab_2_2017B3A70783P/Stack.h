#include "linkedlist.h"
//#include<stdio.h>
// function declarations
//void push(struct linkedlist *head,int ele);
//struct node * pop (struct linkedlist *head);
//void printstack(struct linkedlist *head);
void push(struct linkedList *head, int ele);
struct node * pop (struct linkedList *head);
void printstack (struct linkedList *head);
