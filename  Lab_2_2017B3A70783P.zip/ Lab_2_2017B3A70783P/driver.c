//driver.c
#include<stdlib.h>
#include "Stack.h"

int main(int argc, char *argv[])
{
  FILE *fileptr = fopen(argv[1], "r");
  if (fileptr == NULL)
  {
     printf("File Not Found");
     return(1);
  }
  
  struct linkedList * head = (struct linkedList *) malloc(sizeof(struct linkedList));

while( !feof(fileptr)){
   int temp;
   if( fscanf(fileptr,"%d",&temp) != EOF){

   push(head,temp);
   }
}

fclose(fileptr);

printstack(head);

printf("\nTotal elements in stack are:= %d\n",head->count);

while(head->count != 0)
{
  struct node* del = pop(head);
  printf("\nElement popped is:= %d\n",del->ele);
  printf("\n Total elements remaining in stack are:=%d\n",head->count);
}


}

