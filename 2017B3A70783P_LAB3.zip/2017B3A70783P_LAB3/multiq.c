#include<stdio.h>
#include <stdlib.h>
#include"multiq.h"
int size;
MultiQ createMQ (int num)
{
    MultiQ  mq=(MultiQ )malloc(sizeof(bg )*num);
    //mq->start 
    for(int i=0;i<num;i++)
    {
        //struct Queue* t=(struct Queue *)malloc(sizeof(struct Queue));
           mq[i] = newQ();
          if(i==0)
          //mq->start=mq[i];
          (( mq[i])-> pri)=i;
 
    }
    printf("Creating MultiQ of length=%d",num);
   // mq->start=mq[0];
    size=num;
    return mq;
   
}
int sizeMQ( MultiQ  mq)
{
    printf("\n size is%d\n ",size);
    return size;
}
MultiQ addMQ (MultiQ  mq,  Task t)
{
    int n= sizeMQ(mq);
    for(int i=0;i<n;i++)
    {
        if((t->pri)==(mq[i]->pri))
        {
            mq[i]=addQ(mq[i],t);
             printf("Added task");
            //size++;
            return mq;
        }
    }
   
    return mq;
}
Task  nextMQ(  MultiQ  mq)
{
    int n=sizeMQ(mq);
    int temp=mq[0]->pri;
    int s=0;
    for(int i=1;i<n;i++)
    {
       if(mq[i]->pri >temp)
       {
           temp=mq[i]->pri;
           s=i;
       }
    }

   return mq[s]->front;
}
int sizeMQbyPriority( MultiQ  mq,int pk)
{
    int c=0;
    int n=sizeMQ(mq);
    int temp=mq[0]->pri;
    int s=0;
    for(int i=1;i<n;i++)
    {
       if(mq[i]->pri ==pk)
       {
            
           c++;
       }
    }
    return c;

}
bool isEmptyMQ(MultiQ  mq)
{
   int n=sizeMQ(mq);
    //int temp=mq[0]->p->pri;
    //int s=0;
    for(int i=0;i<n;i++)
    {
        if(isEmptyQ(mq[i])==0)
        {
            return false;
        }
    }
    return true;
}
Task getQueueFromMQ( MultiQ mq,int pk)
{
    int n=sizeMQ(mq);
    int temp=mq[0]->pri;
    int s=0;
    for(int i=0;i<n;i++)
    {
       if(mq[i]->pri ==pk)
       {
            
           return mq[i]->front;
       }
    }
    return NULL;
}
MultiQ delNextMQ( MultiQ  mq)
{
    int n=sizeMQ(mq);
    int temp=mq[0]->pri;
    int s=0;
    for(int i=1;i<n;i++)
    {
       if(mq[i]->pri >temp)
       {
            
           temp=mq[i]->pri;
           s=i;
       }
    }
    delQ(mq[s]);
    size--;
    return mq;
}