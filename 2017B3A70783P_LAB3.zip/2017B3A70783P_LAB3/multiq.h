#include<stdio.h>
#include "que.h"

typedef struct Queue * bg;


typedef bg* MultiQ;


typedef  struct Element* Task;
MultiQ  createMQ(int num);
MultiQ addMQ( MultiQ  mq, Task t);

 Task  nextMQ(  MultiQ  mq);
 MultiQ delNextMQ( MultiQ  mq);
 bool isEmptyMQ(MultiQ  mq);
int sizeMQ( MultiQ  mq);
int sizeMQbyPriority( MultiQ  mq, int pk);
Task getQueueFromMQ( MultiQ mq, int pk);
