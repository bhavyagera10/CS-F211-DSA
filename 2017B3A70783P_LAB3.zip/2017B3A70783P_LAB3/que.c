#include<stdio.h>
#include<stdlib.h>
#include "que.h"


struct Queue * newQ()
{
    struct Queue * n= (struct Queue *)malloc(sizeof(struct Queue));
    n->front=NULL;
    n->rear=NULL;
    printf("\nnew Queue added\n");
     return n;  
 
}
bool isEmptyQ(struct Queue *n)
{
    if(n->front==NULL && n->rear==NULL)
    {
        printf("\nQueue is empty\n");
        return true;
    }
    return false;
}

struct Queue * delQ(struct Queue * q)
{
    struct Element * temp= q->front;
    if(temp==NULL) {return NULL;}
    q-> front= q->front->next;
    printf("\nDeleted Queue\n");
    free(temp); 
    return q;
}

struct Element* front(struct Queue * q)
{
    if(q-> front==NULL)
    return NULL;
    printf("\nReturned front successfuly\n");
    struct Element *e= q->front;
    return e;

}

 struct Queue *addQ(struct Queue *q, struct Element *e )
{
    struct Element * temp=q-> rear;
   // q->front= e;
   printf("\nAdded Queue successfuly %d priority\n",q->pri);
   if(q->front==NULL && q->rear==NULL)
   {
       q->front=e;
       q->rear=e;
       return q;
   }
    temp->next =e;
    q->rear=e;
    return q;
}

struct Queue *lengthQ(struct Queue *q)
{
    q->len=0;
    printf("Returning length");
    while(q->front <= q->rear && q->front!=NULL )
    {
        q->len++;
        q->front=((q->front)->next);
    }
    return q; 
}
