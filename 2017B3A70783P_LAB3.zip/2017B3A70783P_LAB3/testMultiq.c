#include "multiq.h"
#include<sys/time.h>
#include<stdlib.h>
#include<stdio.h>
typedef char File[32];

MultiQ loadData(File file, int n){
 MultiQ mq = createMQ(n++);
 FILE *f = fopen(file,"r");
 int tid,p;
 
 
 while(!feof(f)){
  fscanf(f,"%d,%d\n",&tid,&p);
  Task t=(Task)malloc(sizeof(Task));
  
  t->key=tid; t->pri=p; t->next=NULL;
  addMQ(mq,t);
 }
 return mq;
}

MultiQ testDel(int num, MultiQ mq){
 for(int j=0;j<num;j++) {
     delNextMQ(mq);
 }
 return mq;
}

int main(int argc, char *argv[]){
 if(argc != 3){
  printf("ERROR!!");
  return 0;
 }
 int n=atoi(argv[2]);
 
 struct timeval t1, t2, t3;
 double loadtime, deltime;
 gettimeofday(&t1, NULL);//stop timer
 MultiQ mq = loadData(argv[1],n);

 gettimeofday(&t2,NULL);//stop timer
 testDel(n,mq);

 gettimeofday(&t3,NULL);

 loadtime = (t2.tv_sec - t1.tv_sec) * 1000.0;
 loadtime += (t2.tv_usec - t1.tv_usec) / 1000.0;

 deltime = (t2.tv_sec - t1.tv_sec) * 1000.0;
 deltime += (t2.tv_usec - t1.tv_usec) / 1000.0;
 printf("\n  AVERAGE LOADING TIME : %lf ms.\n  AVERAGE DELETION TIME : %lf\n",loadtime/n,deltime/n);
 return 0;
}
