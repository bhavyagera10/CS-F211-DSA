 #include<stdio.h>
#include<stdbool.h>
struct node
{
   int ele;
   struct node* next;
};

struct linkedList
{
    struct node* first;
    int count;

};

struct Element
{
 int key;
 struct Element* next;
 int pri;

};

struct Queue
{
   struct Element* front;
   struct Element * rear; 
   int len;
   int pri;
};
struct Queue * newQ();
bool isEmptyQ();
struct Queue * delQ(struct Queue * q);
struct Element *front(struct Queue * q);
struct Queue * addQ(struct Queue *q, struct Element *e);
struct Queue * lengthQ(struct Queue * q);