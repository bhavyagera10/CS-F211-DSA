#include"creditcard.h"
int *top;
void insertInOrder(credit_card * ca, int n, credit_card newc);
void insertionSort(credit_card * ca, int n);
void timeforReading();
void timeforSorting();
void spaceforSorting();
void timeforReadingTest(char * fname,char *tname);
void timeforSortingTest(char * fname,char *tname);
void spaceforSortingTest(char * fname,char *tname);

