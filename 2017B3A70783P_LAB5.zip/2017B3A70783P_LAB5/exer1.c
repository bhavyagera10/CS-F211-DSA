#include<stdio.h>
#include<stdlib.h>
#include"creditcard.h"

credit_card* readcards(credit_card* ca, char* fname,int* fsize)
{
     int size=5;
     ca=(credit_card*)malloc(sizeof(credit_card)*size);
     FILE * fptr=fopen(fname,"r");

     if(fptr==NULL)
     {
         printf("error opening file\n");
         exit(0);
     }
     credit_card newc; 

     int i=0;

     while(!feof(fptr))
     {
         fscanf(fptr,"\"%lu,%[^,],%[^,],%[^,],%[^\"]\"\n",&newc.cardno,newc.bankcode,newc.exdate,newc.fname,newc.lname);
         ca[i++]=newc;
         if(i==size)
         {
             size*=2;
             ca=realloc(ca,sizeof(credit_card)*size);
            
         }
        
     }
    fclose(fptr);
         *fsize=i;
         return ca;


}