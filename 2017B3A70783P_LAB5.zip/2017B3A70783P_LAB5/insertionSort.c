#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"insertionsort.h"
//#include"creditcard.h"

void insertInOrder(credit_card * ca, int n, credit_card newc)
{
     credit_card last=ca[n-1];
     credit_card temp;
     int j=n-2;
     while(j>=0 && (ca[j].cardno>last.cardno))
     {
          ca[j+1]=ca[j];
          j--; 
     }
     ca[j+1]=last;
}

void insertionSort(credit_card * ca, int n)
{
    if(n==0)
      {    top=&n;
           return ;}
      insertionSort(ca,n-1);
      insertInOrder(ca,n,ca[n-1]);

}