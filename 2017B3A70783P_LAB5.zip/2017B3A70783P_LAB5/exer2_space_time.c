#include<stdio.h>
#include<stdlib.h>
#include<time.h>
//#include<system/time.h>
//#include"creditcard.h"
#include"insertionsort.h"

 
void timeforReading()
{
	credit_card* ca;
	int size;
	FILE * fptr=fopen("results.txt","w");
	char fname[10];
	struct timeval t1,t2;
	double elapsedtime;
	int check;

	for(int i=1;i<8;i++)
	{
		check=pow(10,i);
		gettimeofday(&t1,NULL);
		if(i<5)
		{
			sprintf(fname,"%d",check);
			ca=readcards(ca,fname,&size);
		}
		else
		{
			for(int j=0;j<check/100000;j++)
			{
				ca=readcards(ca,fname,&size);
			}
		}
		gettimeofday(&t2,NULL);
		elapsedtime=(t2.tv_sec- t1.tv_sec)* 1000.0;
		elapsedtime+=(t2.tv_usec-t1.tv_usec)/1000.0;
		fprintf(fptr,"%d structs in %lf millisecond\n",check,elapsedtime);


		
	}
	fclose(fptr);
}


void timeforSorting()
{
	credit_card* ca;
	int size;
	FILE * f=fopen("resultsAfterSort.txt","w");
	char fname[10];
	int ch;
	struct timeval t1,t2;
	double elapsedtime;
	for(int j=1;j<6;j++)
	{
         ch=pow(10,j);
		 gettimeofday(&t1,NULL);
		 if(j<5)
		 {
			 sprintf(fname,"%d",ch);
			 ca=readcards(ca,fname,&size);
		 }

		 else
		 {
			  for(int i=0;i<ch/100000;i++)
			  {
				  ca=readcards(ca,fname,&size);
			  }
		 }
		 insertionSort(ca,size);
		 gettimeofday(&t2,NULL);
		 elapsedtime=(t2.tv_sec-t1.tv_sec)*1000.0;
		 elapsedtime+=(t2.tv_usec-t1.tv_usec)/1000.0;
		 fprintf(f,"%d sorted structs in %lf milliseconds\n",ch,elapsedtime);
		 

	}
	fclose(f);
}
 
 void spaceforSorting()
 {
	 credit_card* ca;
	 int size;
	 FILE* ff=fopen("resultSpaceSort.txt","w");
	 char fname[10];
	 int ch;
	 for(int i=1;i<8;i++)
	 {
          int last;
		  ch=pow(10,i);
		  
		  if(i<5)
		  {
			  sprintf(fname,"%d",ch);
			  ca=readcards(ca,fname,&size);
		  }
		  else
		  {
			   for(int j=0;j<ch/100000;j++)
			   {
				   ca=readcards(ca,fname,&size);
			   }
		  }
		  insertionSort(ca,size);
		  fprintf(ff,"Number of sorted elements=%d, top of stack =%p,bottom of stack=%p, Space used=%llu\n",ch,top,&last,(unsigned long long)&last-(unsigned long long )top);

	 }
	 fclose(ff);
 }
 void timeforReadingTest(char * fname, char* tname)
 {
	 credit_card * ca;
	int size;
	FILE * f=fopen(tname,"a");
	struct timeval t1, t2;
	double elapsedTime;
		
	gettimeofday(&t1, NULL);
	ca=readcards(ca,fname,&size);
	//insertionSort(ca,size);
	gettimeofday(&t2, NULL);
	elapsedTime = (t2.tv_sec - t1.tv_sec) * 1000.0;
	elapsedTime += (t2.tv_usec - t1.tv_usec) / 1000.0;
	fprintf(f, "Read %d structs in %lf milliseconds.\n",size,elapsedTime);
	fclose(f);
 }

void timeforSortingTest(char * fname, char* tname)
{
	credit_card * ca;
	int size;
	FILE * f=fopen(tname,"a");
	struct timeval t1, t2;
	double elapsedTime;
		
	gettimeofday(&t1, NULL);
	ca=readcards(ca,fname,&size);
	insertionSort(ca,size);
	gettimeofday(&t2, NULL);
	elapsedTime = (t2.tv_sec - t1.tv_sec) * 1000.0;
	elapsedTime += (t2.tv_usec - t1.tv_usec) / 1000.0;
	fprintf(f, "Sorted %d structs in %lf milliseconds.\n",size,elapsedTime);
	fclose(f);
}

void spaceforSortingTest(char * fname,char * tname)
{
     credit_card* ca;
	 int size;
	 FILE *f=fopen(tname,"a");
	 int last;
	 ca=readcards(ca,fname,&size);
	 insertionSort(ca,size);
	 fprintf(f,"Number of sorted elements=%d, top of stack =%p,bottom of stack=%p, Space used=%llu\n",size,top,&last,(unsigned long long)&last-(unsigned long long )top);
     fclose(f);
}