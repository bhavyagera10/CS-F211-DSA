#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<math.h>
#ifndef credit_card_h
typedef struct 
{
    unsigned long cardno;
    char bankcode[5];
    char exdate[8];
    char fname[20];
    char lname[20];

}credit_card;
#endif

credit_card * readcards(credit_card* ca, char* fname,int* fsize);