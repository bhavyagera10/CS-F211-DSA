
#include "insertionsort.h"


int main(int argc, char* argv[]){
    //spaceforSorting();
	timeforReadingTest(argv[1],argv[2]);
	timeforSortingTest(argv[1],argv[2]);
	spaceforSortingTest(argv[1],argv[2]);
	//spaceforSorting();
}